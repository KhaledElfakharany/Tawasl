export let myVar = 942;
export let func1 = () => {
  console.log('Hello from func1');
}
export let func2 = () => {
  console.log('Hello from func2');
}

// module.exports = {
//   myVar: myVariable,
//   func1: func1,
//   func2: func2
// };
